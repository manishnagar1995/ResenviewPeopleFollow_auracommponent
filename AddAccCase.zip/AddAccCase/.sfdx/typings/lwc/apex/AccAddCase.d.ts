declare module "@salesforce/apex/AccAddCase.lineOfBusinessListOptions" {
  export default function lineOfBusinessListOptions(): Promise<any>;
}
declare module "@salesforce/apex/AccAddCase.saveCaseData" {
  export default function saveCaseData(param: {accCaseData: any, lob: any}): Promise<any>;
}
