declare module "@salesforce/apex/LexRecentviwedPeopleController.getUserData" {
  export default function getUserData(param: {pageNumber: any, pageSize: any}): Promise<any>;
}
declare module "@salesforce/apex/LexRecentviwedPeopleController.followRecord" {
  export default function followRecord(param: {recordId: any, isFollowed: any}): Promise<any>;
}
