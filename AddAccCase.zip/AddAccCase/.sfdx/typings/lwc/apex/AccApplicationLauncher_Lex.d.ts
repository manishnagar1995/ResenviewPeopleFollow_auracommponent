declare module "@salesforce/apex/AccApplicationLauncher_Lex.hasAppMethod" {
  export default function hasAppMethod(param: {contextUserid: any}): Promise<any>;
}
