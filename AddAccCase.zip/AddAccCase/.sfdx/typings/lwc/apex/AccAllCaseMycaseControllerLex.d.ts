declare module "@salesforce/apex/AccAllCaseMycaseControllerLex.createLineOfBusinessOptionList" {
  export default function createLineOfBusinessOptionList(): Promise<any>;
}
declare module "@salesforce/apex/AccAllCaseMycaseControllerLex.getCaseData" {
  export default function getCaseData(): Promise<any>;
}
declare module "@salesforce/apex/AccAllCaseMycaseControllerLex.retrieveCases" {
  export default function retrieveCases(): Promise<any>;
}
