import { LightningElement, api,track,wire} from 'lwc';
//import { getObjectInfo} from 'lightning/uiObjectInfoApi';
//import CASE_OBJECT from '@salesforce/schema/Case';
//import { encodeDefaultFieldValues } from 'lightning/pageReferenceUtils';
import { NavigationMixin } from 'lightning/navigation';
import accRecordtypeId from '@salesforce/label/c.Acc_Acxiom_Customer_Center'
import getCaseId from '@salesforce/apex/AccAddCase.saveCaseData';
import lobselectoption from '@salesforce/apex/AccAddCase.lineOfBusinessListOptions';
export default class AccCommunityAddCase extends NavigationMixin (LightningElement) {
activeSections = ['A', 'B'];
label = {
    accRecordtypeId,
};
//@api Case;
//@track recordTypeId;
errorMsg;
//areCaseVisible= true;
@track options=[];
@track lobList = [];
//@api recordId;
//@track placeholdervalue=[];
//areDescriptionVisible= true;
@track isLoading = false;
@track completeComponent=false;
lobSelectedValue = 'None';

 /*   @wire(getObjectInfo, { objectApiName: CASE_OBJECT })
    handleObjectInfo({error, data}) {
        if (data) {
            const recordtypelist = data.recordTypeInfos;
            this.recordTypeId = Object.keys(recordtypelist).find(recordtype => recordtypelist[recordtype].name === 'Acxiom Customer Center');
           console.log("------recordTypeId------",this.recordTypeId);
          //  this.isLoading = false; 
        }
    }*/
    connect
    handleClick(){
        console.log("accRecordtypeId------------"+accRecordtypeId);
        this.completeComponent=true;
        this.isLoading = true;
		lobselectoption().then(result=>
		{
			this.options = result;
			this.errors = undefined;
			var opt = [];
			opt = this.options;
			var optionList = [];
			if(opt){
				for(var i = 0;i<opt.length;i++){
					optionList.push({
						label : opt[i],
						value : opt[i]
					})
				}
			}
        this.lobList = optionList;
        
        console.log('options are--->' ,this.lobList);
			})
		.catch(error=>{
			this.errorMsg = error;
			this.options = undefined;
			
		})

    }
    handleOnload(){
        this.isLoading = false;
    }
    

    handleSubmit(event){
      const fields = event.detail.fields;
        this.isLoading = true;
      getCaseId({accCaseData : fields,lob:this.lobSelectedValue })
        .then(result => {
            console.log('------------',JSON.stringify(result));
         if(result != null){
            this.isLoading = false;
               
           this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: result,
                objectApiName: 'Case',
                actionName: 'view'
            }});
         } })
        .catch(error => {
            this.errorMsg = error;
        });
    }

    hideComponentFirst(){
        if( this.areCaseVisible==true){
            this.areCaseVisible=false;
        }
        else{
            this.areCaseVisible=true;
        }
    }
    handleReset(event) {
        const inputFields = this.template.querySelectorAll('lightning-input-field');
        if (inputFields) {
            inputFields.forEach(field => {
                field.reset();
            });
        }
    }

	handleLOBChange(event){
        this.lobSelectedValue = event.detail.value;
        console.log('---------------',this.lobSelectedValue);
	}
   
}