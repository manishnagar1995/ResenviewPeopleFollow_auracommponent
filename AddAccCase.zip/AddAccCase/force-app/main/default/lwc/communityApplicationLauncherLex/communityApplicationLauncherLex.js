import { LightningElement, api,track,wire} from 'lwc';
import customSR from '@salesforce/resourceUrl/CommunityApplicationIcons';
import USER_ID from "@salesforce/user/Id";
import hasAppMethod from '@salesforce/apex/CommunityApplicationLauncher_Lex.hasAppMethod';
export default class CommunityApplicationLauncherLex extends LightningElement {
    @track accAppList=[];
    data =[];
    @track hasapp= false;
    @track isLoading=true;
    @wire(hasAppMethod,{contextUserid:USER_ID})
    wiredCommunityApp(result) {
        if (result.data) {         
            this.data = result.data;
            let nameUrl;
        
            if(this.data.length > 0){
                this.hasapp= true;
            this.accAppList = this.data.map(row => { 
                this.comSR= customSR;
                nameUrl =this.comSR+'/'+row.Icon__c;
                return {...row , nameUrl} 
            })
            }
            this.error = undefined;
            this.isLoading=false;
        } 
        else if (result.error) {
            this.errors = error;
        }
    
    } 

}