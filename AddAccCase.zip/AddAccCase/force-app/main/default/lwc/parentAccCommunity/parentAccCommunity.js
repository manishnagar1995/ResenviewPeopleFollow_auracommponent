import { LightningElement,track,api,wire } from 'lwc';
import retrieveCases from '@salesforce/apex/AccCommunityHomeControllerLex.retrieveCases';
const columns = [
    {label: 'Case Number', fieldName: 'nameUrl', type: 'url', 
    typeAttributes: {label: { fieldName: 'CaseNumber'}, 
    target: '_top'},
    sortable: true},
    {label: 'Line Of Business', fieldName: 'Line_of_Business__c', type: 'text',sortable: true},
    {label: 'Reason', fieldName: 'Reason', type: 'text',sortable: true},
    {label: 'Subject', fieldName: 'Subject', type: 'text',sortable: true},
    {label: 'Contact Name', fieldName: 'contact.Name', type: 'text',sortable: true},
    {label: 'Case Owner', fieldName: 'owner.Name', type: 'text',sortable: true},
    {label: 'Status', fieldName: 'Status', type: 'text',sortable: true},
    {label: 'Date Opened', fieldName: 'CreatedDate', type: 'date',sortable: true},
    {label: 'Rank', fieldName: 'Ranking__c', type: 'number',sortable: true},
    ]; 

export default class ParentAccCommunity extends LightningElement {

    @track page = 1; //this is initialize for 1st page
    @track items = []; //it contains all the records.
    @track data = []; //data to be display in the table
    @track columns; //holds column info.
    @track startingRecord = 1; //start record position per page
    @track endingRecord = 0; //end record position per page
    @track pageSize = 10; //default value we are assigning
    @track totalRecountCount = 0; //total record count received from all retrieved records
    @track totalPage = 0; //total number of page is needed to display all records
    
    //Sorting fields below

    @track rowOffset = 0;
    @track sortedBy;
    @track tableLoadingState = true;
    @track sortedDirection;
    @track recorddata;
    @wire(retrieveCases)
    
    wiredAccounts(result) {

        this.recorddata= result;

        if (result.data) {     
    
            this.items =  result.data.map(record => Object.assign(
            
                { "nameUrl": 'https://partial-acxiomcommunity.cs17.force.com/acc/s/case/'+record.Id +'/'+ record.Subject},
                  record
               ));
                console.log('this.data',this.data);
                this.data  = this.items;
 
            this.totalRecountCount = this.data.length; 
            this.totalPage = Math.ceil(this.totalRecountCount / this.pageSize); 
         
            this.data = this.items.slice(0,this.pageSize); 
            this.endingRecord = this.pageSize;
            this.columns = columns;
            this.error = undefined;

        } else if (result.error) {
            this.errors = error;
        }
        this.tableLoadingState = false;
    }
    //sortin of ascending and decending starts
    increaseRowOffset() {
        this.rowOffset += 1;
    }
    updateColumnSorting(event) {
        
    let fieldName = event.detail.fieldName;
    let sortDirection = event.detail.sortDirection;
        this.sortedBy = fieldName;
        this.sortedDirection = sortDirection;

        console.log('Sort fieldName: ' + fieldName);
        console.log('sort direction: ' + sortDirection);

        let reverse = sortDirection !== 'asc';
        let data_clone = JSON.parse(JSON.stringify(this.data));
        console.log('BEFORE data_clone:' + JSON.stringify(data_clone));
        this.data = data_clone.sort(this.sortBy(fieldName, reverse));
        console.log('AFTER data_clone:' + JSON.stringify(data_clone));

    }
    sortBy (field, reverse, primer){
        console.log('Sort by:reverse:' + reverse);
        var key = function (x) {return primer ? primer(x[field]) : x[field]};
        return function (a,b) {
        var A = key(a), B = key(b);
        if (A === undefined) A = '';
        if (B === undefined) B = '';
        return (A < B ? -1 : (A > B ? 1 : 0)) * [1,-1][+!!reverse];                 
        }
    }
      // //sortin of ascending and decending ends here---------------------
   
    previousHandler() {
        if (this.page > 1) {
            this.page = this.page - 1; 
            this.displayRecordPerPage(this.page);
        }
    }
    nextHandler() {
        if((this.page<this.totalPage) && this.page !== this.totalPage){
            this.page = this.page + 1; 
            this.displayRecordPerPage(this.page);            
        }             
    }
    //this method displays records page by page
    displayRecordPerPage(page){
        this.startingRecord = ((page -1) * this.pageSize) ;
        this.endingRecord = (this.pageSize * page);
        this.endingRecord = (this.endingRecord > this.totalRecountCount) 
                            ? this.totalRecountCount : this.endingRecord; 
        this.data = this.items.slice(this.startingRecord, this.endingRecord);
        //increment by 1 to display the startingRecord count, 
        //so for 2nd page, it will show "Displaying 6 to 10 of 23 records. Page 2 of 5"
        this.startingRecord = this.startingRecord + 1;
    }   
    
}