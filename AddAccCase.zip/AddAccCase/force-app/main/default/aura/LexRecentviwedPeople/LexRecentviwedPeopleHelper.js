({
    getContactList: function(component, pageNumber, pageSize) {
        var action = component.get("c.getUserData");
      //  alert("hi");
        action.setParams({
            "pageNumber": pageNumber,
            "pageSize": pageSize
        });
        action.setCallback(this, function(result) {
              //debugger;
            var state = result.getState();
            if (component.isValid() && state === "SUCCESS"){
              console.log("##################",result.getReturnValue());
                var resultData = result.getReturnValue();
                
               component.set("v.PageNumber", resultData.pageNumber);
               component.set("v.TotalRecords", resultData.totalRecords);
               component.set("v.RecordStart", resultData.recordStart);
               component.set("v.RecordEnd", resultData.recordEnd);
                component.set("v.TotalPages", Math.ceil(resultData.totalRecords / pageSize));
                var followusermap = resultData.userfollowmap;
                  console.log("$$$asdasdfg======",followusermap);
                var followUsers = [];
              /*  for (var key in followusermap ) {
                   console.log("$$$======",key);
                   // console.log("$$$======",followusermap[key]);
                        followUsers.push({value:followusermap[key], key:key});
                   // console.log("$$@@@$======",followUsers);
                }*/
                 component.set("v.UserMap",followusermap);
                console.log("$$$1243======",followUsers);
               
            }
        });
        $A.enqueueAction(action);
    }
    
    
})